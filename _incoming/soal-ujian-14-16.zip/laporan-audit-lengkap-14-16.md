# Laporan Lengkap Ekstraksi & Audit Paket Soal Ujian 14, 15, dan 16 (SSW PM)

## 1. Ringkasan Paket & Statistik
| Paket | Nama File JSON | `setId` | Sumber PDF | Jumlah Halaman | Jumlah Soal | Bobot / Soal | Skor Maks | Soal Bergambar |
|---|---|---|---|---:|---:|---:|---:|---:|
| **Soal Ujian 14** | `kunci-ujian-14.json` / `ssw-pm-kunci-ujian-14.json` | `ssw-pm-kunci-ujian-14` | `Soal Ujian 14.pdf` | 16 | **59** (32 学科 + 2 実技 + 25 参考) | 2.54 | 150 | 2 (`q033`, `q034`) |
| **Soal Ujian 15** | `kunci-ujian-15.json` / `ssw-pm-kunci-ujian-15.json` | `ssw-pm-kunci-ujian-15` | `Soal Ujian 15.pdf` | 12 | **38** (`1`–`38`) | 3.95 | 150 | 3 (`q035`, `q036`, `q038`) |
| **Soal Ujian 16** | `kunci-ujian-16.json` / `ssw-pm-kunci-ujian-16.json` | `ssw-pm-kunci-ujian-16` | `Soal Ujian 16.pdf` | 19 | **50** (40 学科 + 10 実技) | 3.00 | 150 | 6 (`q041`, `q042`, `q046`, `q047`, `q048`, `q049`) |
| **TOTAL** | **3 Paket** | — | **3 PDF** | **47** | **147 Soal** | — | — | **11 Gambar** |

## 2. Hasil Audit Kunci Jawaban (`laporan-audit-kunci-jawaban.json`)
Seluruh **147 soal** telah diverifikasi secara independen terhadap buku teks resmi SSW Pengolahan Makanan (飲食料品製造業技能測定試験学習用テキスト) dan perhitungan matematis:
- **`VERIFIED_CORRECT`**: **146 soal** (kunci pada PDF sumber cocok 100% dengan standar buku teks dan perhitungan).
- **`QUESTION_DEFECTIVE` / `review_required`**: **1 soal** (`kunci-ujian-15-q011`, `Soal Ujian 15.pdf` halaman 3–4 nomor 11):
  - **Pertanyaan**: Menanyakan prinsip ke-3 pencegahan mikroorganisme keracunan makanan selain 「つけない」 dan 「増やさない」.
  - **Temuan**: Secara keilmuan prinsip ke-3 adalah **「やっつける（殺す）」** (membunuh bakteri). Namun pada PDF sumber (`ĐỀ SỐ 3`), ketiga pilihan jawaban tercetak dalam bentuk negatif: `A. 殺さない` (tidak membunuh), `B. 生まれさせない` (tidak membiarkan lahir), `C. 下げない` (tidak menurunkan), dan tabel `Đáp án` di halaman 12 menandai **`11.B`**.
  - **Penanganan**: Sesuai aturan integritas ekstraksi, teks asli dan kunci `B` dipertahankan, properti `questionTextStatus` ditandai `"review_required"`, `answerVerificationStatus` ditandai `"QUESTION_DEFECTIVE"`, dan catatan lengkap disertakan pada field `explanation`.
- **Verifikasi Soal Hitungan (4 Soal)**:
  1. `kunci-ujian-14-q034` (`Soal Ujian 14.pdf` hlm. 9, 実技 問題2): 300 g roti butuh 200 g terigu $ightarrow$ 4 kg (4.000 g) terigu menghasilkan $rac{4000}{200} 	imes 300 = 6.000	ext{ g} = \mathbf{6	ext{ kg}}$ (**B** — cocok dengan kunci PDF).
  2. `kunci-ujian-15-q033` (`Soal Ujian 15.pdf` hlm. 9, No. 33): Membuat 1 L (1.000 ml) larutan NaClO 200 ppm (0,02%) dari larutan induk 10% $ightarrow$ Larutan induk $= rac{1000 	imes 0,02\%}{10\%} = \mathbf{2	ext{ ml}}$, Air $= 1000 - 2 = \mathbf{998	ext{ ml}}$ (**B** — cocok dengan kunci PDF).
  3. `kunci-ujian-15-q037` (`Soal Ujian 15.pdf` hlm. 11, No. 37): 450 g udon butuh 300 g terigu $ightarrow$ 10 kg terigu menghasilkan $rac{10}{0,3} 	imes 0,45 = \mathbf{15	ext{ kg}}$ (**B** — cocok dengan kunci PDF).
  4. `kunci-ujian-16-q041` (`Soal Ujian 16.pdf` hlm. 14–15, 実技 門1): 300 g roti butuh 200 g terigu $ightarrow$ 5 kg (5.000 g) terigu menghasilkan $rac{5000}{200} 	imes 300 = 7.500	ext{ g} = \mathbf{7,5	ext{ kg}}$ (**C** — cocok dengan kunci PDF).
  5. `kunci-ujian-16-q042` (`Soal Ujian 16.pdf` hlm. 15, 実技 門2): 5 buah gyoza butuh 200 g daging babi cincang $ightarrow$ 1,2 kg (1.200 g) daging menghasilkan $rac{1200}{200} 	imes 5 = \mathbf{30	ext{ 個}}$ (**C** — cocok dengan kunci PDF).

## 3. Hasil Audit Visual & Aset Gambar (`manifest-referensi-gambar.json`)
Seluruh **11 gambar soal** diekstrak/dipotong hanya pada area ilustrasi atau tabel spesifik (0 gambar halaman penuh), ditingkatkan resolusinya, dan diverifikasi kecocokannya dengan teks soal:
| ID Soal | File Gambar | Resolusi (px) | Halaman PDF | Deskripsi Visual |
|---|---|---:|---:|---|
| `kunci-ujian-14-q033` | `assets/questions/kunci-ujian-14-q033.png` | `1329x1878` | Hlm. 9 | Ilustrasi pekerja mengoperasikan mesin pencetak adonan roti (moulder) |
| `kunci-ujian-14-q034` | `assets/questions/kunci-ujian-14-q034.png` | `819x716` | Hlm. 9 | Tabel komposisi 300 g roti (小麦粉 200g, 食塩 20g, 水 80g) |
| `kunci-ujian-15-q035` | `assets/questions/kunci-ujian-15-q035.png` | `1128x1172` | Hlm. 10 | Ilustrasi tangan pekerja terjepit konveyor saat mengelap dengan kain lap |
| `kunci-ujian-15-q036` | `assets/questions/kunci-ujian-15-q036.png` | `1120x1192` | Hlm. 11 | Ilustrasi pekerja terpeleset bunga es (霜) di lantai ruang pembeku |
| `kunci-ujian-15-q038` | `assets/questions/kunci-ujian-15-q038.png` | `1124x1088` | Hlm. 12 | Ilustrasi pekerja terpeleset saat menginjak roller conveyor yang bergerak |
| `kunci-ujian-16-q041` | `assets/questions/kunci-ujian-16-q041.png` | `900x500` | Hlm. 15 | Tabel komposisi 300 g roti (小麦粉 200g, 食塩 20g, 水 80g) |
| `kunci-ujian-16-q042` | `assets/questions/kunci-ujian-16-q042.png` | `900x500` | Hlm. 15 | Tabel komposisi 5 buah gyoza (豚ひき肉 200g, キャベツ 200g, みりん 6g) |
| `kunci-ujian-16-q046` | `assets/questions/kunci-ujian-16-q046.png` | `1305x1446` | Hlm. 17 | Ilustrasi pekerja mengelap konveyor yang masih berputar dengan kain lap |
| `kunci-ujian-16-q047` | `assets/questions/kunci-ujian-16-q047.png` | `1266x1512` | Hlm. 18 | Ilustrasi pekerja hilang keseimbangan akibat tekanan air selang saat bersih-bersih |
| `kunci-ujian-16-q048` | `assets/questions/kunci-ujian-16-q048.png` | `1275x1248` | Hlm. 18 | Ilustrasi pekerja menginjak troli (台車) tanpa stopper saat menumpuk barang |
| `kunci-ujian-16-q049` | `assets/questions/kunci-ujian-16-q049.png` | `1024x1058` | Hlm. 19 | Ilustrasi pekerja mengepel lantai dengan mop yang diperas di dekat peralatan listrik |

## 4. Hasil Audit Kotoba & Validasi Skema JSON
- **Total Entri Soal Ber-Kotoba**: 147 soal (100% terisi `kotobaU`, `kotobaV`, dan `kotobaFormatted`, serta terintegrasi ke dalam `kotoba-dan-kategori-tambahan.json` sehingga total kamus menjadi **728 soal**).
- **Jumlah Pecahan Kanji Tunggal**: **0** (seluruh kosakata diekstrak sebagai satuan leksikal/kata majemuk utuh beserta furigana dan arti bahasa Indonesia yang akurat).
- **Validasi Skema (`validateQuestion` pada `utils.js`)**: **147/147 soal LULUS (0 error)**.
